// #include<bits/stdc++.h>
#include<iostream>
using namespace std;
int fact=1;

int factorial(int n){
    if(n>100){
        for(int i=1;i<n;i++){
            fact=fact*i;

        }
        
    }
    return fact;
}
int main(){
    int num;
    cin>>num;
    cout<<factorial(num);
}