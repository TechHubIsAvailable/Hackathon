#include<bits/stdc++.h>
using namespace std;
int merge(int array1[],int array2[]){

}
int main(){
    int array1[]={4,3,2,1};
    int array2[]={9,8,7};
    int array3[7];


    for(int i=0;i<4;i++){
        array3[i]=array1[i];
    }
    for(int i=0;i<3;i++){
        array3[i+4]=array2[i];
    }
    cout<<"Merged"<<endl;
    for(int i=0;i<7;i++){
        cout<<array3[i]<<"  ";
    }
    
    for(int i=0;i<7;i++){
        for(int j=0;j<(7-i);j++){
            if(array3[j]>array3[j+1]){
                int temp=array3[j];
                array3[j]=array3[j+1];
                array3[j+1]=temp;
            }
        }
    }
    cout<<"\nSorted"<<endl;
    for(int i=0;i<7;i++){
        cout<<array3[i]<<"  ";
    }
    
    





}